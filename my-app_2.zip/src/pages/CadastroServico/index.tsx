import { Flex, Heading, Stack, Switch, Text, Button, useMediaQuery } from '@chakra-ui/react';
import Head from 'next/head';
import Link from 'next/link';
import React from 'react';
import Sidebar from '../../components/siderBar';
import { canSSRAuth } from '../../utils/canSSRAuth';
import { IoMdPricetag } from 'react-icons/io'
// import { Container } from './styles';

export default function CadastroServico() {

  const [isMobile] = useMediaQuery('(max-width: 500px)')

  return (
    <>
      <Head>
        <title>Painel - Lista de Serviços</title>
      </Head>
      <Sidebar />
      <div className="relative md:ml-64">
         <div className="relative md:pt-0 "></div>

        <Flex p={5} direction={'column'} flex={1} alignItems={'flex-start'} justifyContent="flex-start">
          <Flex
            direction={isMobile ? 'column' : 'row'}
            w="100%"
            alignItems={isMobile ? 'flex-start' : 'row'}
            justifyContent='flex-start'
            mb={0}
          >
            <Heading
              fontSize={isMobile ? '28px' : '3xl'}
              mt={4}
              mb={4}
              mr={4}
              color='primary'
            >
              Lista de serviços
            </Heading>

            <Link href={'/CadastroServico/new'}>
              <Button
                bg="#F0F0F5"
                mt={4}

              >
                + Adicionar serviço
              </Button>
            </Link>

            <Stack mb={2}  ml='auto' align={isMobile ? 'flex-start' : 'center'} direction='row'>
              <Text fontWeight="bold">ATIVOS</Text>
              <Switch
                colorScheme={'green'}
                size='lg'
              />
            </Stack>
          </Flex>


          <Link href={'#'}>
            <Flex
              cursor="pointer"
              w="100%"
              p={4}
              bg="#F0F0F5"
              direction={isMobile ? 'column' : 'row'}
              align={isMobile ? 'flex-start' : 'center'}
              rounded="4"
              mb={2}
              justifyContent="space-between"
            >
              <Flex mb={isMobile ? 2 : 0} direction="row" alignItems="center" justifyContent="center">
                <IoMdPricetag size={28} color={'#A94591'} />

                <Text fontWeight="bold" ml={4} noOfLines={2} color="#000">
                  Cabelo
                </Text>
              </Flex>

              <Text fontWeight="bold" color="#000">
                Valor: R$ 50.00
              </Text>
            </Flex>
          </Link>

          <Link href={'#'}>
            <Flex
              cursor="pointer"
              w="100%"
              p={4}
              bg="#F0F0F5"
              direction={isMobile ? 'column' : 'row'}
              align={isMobile ? 'flex-start' : 'center'}
              rounded="4"
              mb={2}
              justifyContent="space-between"
            >
              <Flex mb={isMobile ? 2 : 0} direction="row" alignItems="center" justifyContent="center">
                <IoMdPricetag size={28} color={'#A94591'} />

                <Text fontWeight="bold" ml={4} noOfLines={2} color="#000">
                  Unhas
                </Text>
              </Flex>

              <Text fontWeight="bold" color="#000">
                Valor: R$ 50.00
              </Text>
            </Flex>
          </Link>


        </Flex>


      </div>

    </>
  )
}



export const getServerSideProps = canSSRAuth(async (ctx) => {

  return {
    props: {}
  }
})
