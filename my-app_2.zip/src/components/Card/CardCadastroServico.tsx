import { Heading, Highlight, Select, Switch, Stack, Text } from '@chakra-ui/react';
import React from "react";
import { Input } from "../ui/Input";
import { Btn } from "../ui/Button";

// components


interface CardCadastroServicoProps {

  title: string;

}

export default function CardCadastroServico() {
  return (
    <>
      <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
        <form>

          <div className="flex flex-wrap mt-5 ">
            <div className="w-full lg:w-12/12 px-4">
              <div className="relative w-full mb-3">
                <label
                  className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                  htmlFor="grid-password"
                >
                  Nome do serviço*
                </label>
                <Input
                  type="text"
                  className=" w-full bg-blueGray-100
                  px-4 py-2 rounded-lg mt-2
                  pl-8 border-b-2 font-display
                  focus:outline-none focus:border-primarycolor transition-all duration-500 capitalize text-lg"
                />
              </div>
            </div>
            <div className="w-full lg:w-12/12 px-4">
              <div className="relative w-full mb-3">
                <label
                  className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                  htmlFor="grid-password"
                >
                  Valor deste serviço*
                </label>
                <Input
                  type="text"
                  className=" w-full bg-blueGray-100
                  px-4 py-2 rounded-lg mt-2
                  pl-8 border-b-2 font-display
                  focus:outline-none focus:border-primarycolor transition-all duration-500 capitalize text-lg"


                />
              </div>
            </div>
            <div className="w-full lg:w-12/12 px-4 mt-3">
              <div className="relative w-full mb-3">
                <Stack mb={6} align="center" direction="row">
                  <label
                    className="block uppercase text-blueGray-600 text-xs font-bold "
                  >
                    Desativar este serviço
                  </label>
                  <Switch
                    size="md"
                    colorScheme="red"
                  />
                </Stack>

              </div>
            </div>
            <div className="w-full lg:w-12/12 px-4">
              <div className="relative w-full mb-3">
                <Btn
                  type='submit'
                  className="
                  w-full  bg-primarycolor
                  text-white rounded-lg px-4 py-3 mt-6
                  "
                >

                  Adicionar
                </Btn>
              </div>
            </div>
          </div>
        </form>
      </div>
    </>
  )
}
