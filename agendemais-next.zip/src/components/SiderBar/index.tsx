import SidenavItems from './items';
import SidenavHeader from './header';
import css from './style.module.css';
import React, { useState, useContext} from 'react';
import { AuthContext } from '../../contexts/AuthContext';


interface styleProps {
  mobilePosition: {
    left: string,
    right: string,
  },
  container: string,
  close: string,
  open: string,
  default: string,
}


const styling: Array<styleProps> = [
    {
    mobilePosition: {
      left: 'left-0',
      right: 'right-0 lg:left-0',
    },
    container: `pb-32 lg:pb-12`,
    close: `duration-700 ease-out hidden transition-all lg:w-24`,
    open: `absolute duration-500 ease-in transition-all w-8/12 z-40 sm:w-5/12 md:w-64`,
    default: `h-screen overflow-y-auto text-white top-0 lg:absolute bg-gray-900 lg:block lg:z-40`,
  }
]
interface SideNavigationProps extends sty {
  mobilePositions: string;
  styles: styleProps;
}


export default function SideNavigation({ mobilePositions, styles }: SideNavigationProps) {
  const { open, ref } = useContext(AuthContext);
  return (
    <aside
      ref={ref}
      className={`${styles.default} ${styles.mobilePosition[mobilePositions]}
        ${open ? style.open : style.close} ${css.scrollbar}`}
    >
      <div className={style.container}>
        <SidenavHeader />
        <SidenavItems />
      </div>
    </aside>
  );
}
