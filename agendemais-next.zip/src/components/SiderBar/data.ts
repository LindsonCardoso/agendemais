import HomeIcon from './icons/home';
import StatusIcon from './icons/status';
import CreditsIcon from './icons/credits';
import ArchivesIcon from './icons/archives';
import SettingsIcon from './icons/settings';
import DocumentationIcon from './icons/documentation';
import { ComponentType, ReactNode } from 'react';


interface SiderBarItemProps {
    title: string,
    icon: any,
    link: string,
}

const data: Array<SiderBarItemProps> = [
  {
    title: 'Home',
    icon:  HomeIcon,
    link: '/',
  },
  {
    title: 'Status',
    icon: StatusIcon,
    link: '/admin/status',
  },
  {
    title: 'Archives',
    icon: ArchivesIcon,
    link: '/admin/archives',
  },
  {
    title: 'Settings',
    icon: SettingsIcon,
    link: '/admin/settings',
  },

];

export default data;
