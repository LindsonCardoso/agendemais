import React, { Children } from 'react';
import { IconType } from 'react-icons/lib';
import { ReactNode, ButtonHTMLAttributes} from 'react';


interface ButtonProps  extends ButtonHTMLAttributes<HTMLButtonElement>{
  icon?: any,
  bgColor?: any,
  color?: any,
  borderRadius?: any,
  size?: any,
  width?: any,
  bgHoverColor?: any,
  text?: any,
  children?: ReactNode,
}

const Button = ({ icon,bgColor,color,size,width,borderRadius,bgHoverColor,text, children, ...rest }: ButtonProps) => {

  return (
    <button
      type="button"
      style={{ backgroundColor: bgColor, color, borderRadius }}
      className={` text-${size} p-3 w-${width} hover:drop-shadow-xl hover:bg-${bgHoverColor}`}
      {...rest}
    >
     {children}
     {icon} {text}
    </button>
  );
};

export default Button;
