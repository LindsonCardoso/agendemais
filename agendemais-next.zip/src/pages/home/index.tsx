import { canSSRAuth } from '../../utils/canSSRAuth'
import Head from 'next/head'
import { Box,} from "@chakra-ui/react";

import { NavBar } from '../../components/Header'
import Sidebar from '../../components/Sidebar';
import Navbar from '../../components/Navbar';
import { AuthContext } from '../../contexts/AuthContext';
import { useContext } from 'react';
import TopNavigation from '../../components/TopNavigate';

interface Props {}


const style = {
  container: `bg-gray-900 h-screen overflow-hidden relative`,
  mainContainer: `flex flex-col h-screen pl-0 w-full lg:pl-20 lg:space-y-4`,
  main: `h-screen overflow-auto pb-36 pt-4 px-2 md:pb-8 md:pt-4 lg:pt-0 lg:px-4`,
};

export default function Home(props: Props) {

  return (
    <>
      <Head>
        <title>Painel - Home+</title>
      </Head>
      <div className={style.container}>
        <div className="flex items-start">
          <div className={style.mainContainer}>
          <TopNavigation />
            <main className={style.main}>

            </main>
          </div>
        </div>
      </div>

    </>
  )
}



export const getServerSideProps = canSSRAuth(async (ctx) => {

  return {
      props: {}
    }
})
