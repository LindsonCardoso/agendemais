
import React, { FormEvent, useContext, useState } from 'react';
import Image from 'next/image';
import { Input } from '../components/ui/Input'
import { Button } from '../components/ui/Button';
import imgLogin from '../assets/login.svg'
import imgWave from '../assets/wave.png'
import { AuthContext } from '../contexts/AuthContext';
import { canSSRGuest } from '../utils/canSSRGuest';
import Head from 'next/head';
import { toast } from 'react-toastify'
import Link from 'next/link';


export default function Login(){
  const { signIn  } = useContext(AuthContext)


  const [login, setLogin] = useState('')
  const [senha, setSenha] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleLogin(event: FormEvent) {
    event.preventDefault();

    if (login === '' || senha === '') {
      toast.error('Preencha os campos')
      return;
    }

    setLoading(true);

    let data = {
      login,
      senha
    }

    await signIn(data);

    setLoading(false);


  }
  return (
    <>
      <Head>
        <title>AgendeMais - Login</title>
      </Head>
      <div className="flex h-screen items-center justify-center">
        <div className="hidden md:block md:w-1/2  lg:w-2/3">

          <div className="fixed hidden lg:block inset-0 h-full img_index" >
            <Image
              src={imgWave}
              alt=''
            />
          </div>

          <div className="hidden lg:block w-1/2 hover:scale-150 transition-all duration-500 transform mx-auto">
            <Image
              src={imgLogin}
              alt=""
            />
          </div>
        </div>

        <div className="m-10 md:w-1/2 w-full lg:w-1/3">
          <h2 className=" text-3xl font-bold mb-5 text-primarycolor text-center">
            Bem-Vindo ao Agende+
            {''}

          </h2>
          <form onSubmit={handleLogin}>

            <div className="flex  flex-col mt-3">
              <i className="fa fa-lock absolute text-primarycolor text-xl"></i>
              <Input
                placeholder='Digite seu login'
                type={'text'}
                className="px-4 py-2 rounded-lg bg-gray-200 mt-2
                pl-8 border-b-2 font-display
                focus:outline-none focus:border-primarycolor transition-all duration-500 capitalize text-lg"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
              />
            </div>

            <div className="flex  flex-col mt-3">
              <i className="fa fa-lock absolute text-primarycolor text-xl"></i>

              <Input
                placeholder='Digite sua senha'
                type={'password'}
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                className="px-4 py-2 rounded-lg bg-gray-200 mt-2
                pl-8 border-b-2 font-display
                focus:outline-none focus:border-primarycolor transition-all
                duration-500 capitalize text-lg"
              />
            </div>

            <Button
              type='submit'
              className="
            w-full  bg-primarycolor
            text-white rounded-lg px-4 py-3 mt-6
            "
            loading={loading}
            >
              Cadastrar
            </Button>



          </form>
          <div className="justify-between items-center flex mt-3">
          <Link href={'/Cadastro'}>
                <a className="items-centertext-gray-600 font-bold cursor-pointer" >
                  {''}Cadastre-se agora!
                </a>

            </Link>

            <Link href={'/Cadastro'}>
                <a className="text-gray-600 font-bold cursor-pointer" >
                  {''} Esqueceu a senha?
                </a>

            </Link>
          </div>

        </div>

      </div>
    </>


  );
}


export const getServerSideProps = canSSRGuest(async (ctx) => {

  return {
      props: {}
    }
})
