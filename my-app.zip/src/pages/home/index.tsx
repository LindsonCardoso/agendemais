import styles from './styles.module.scss'
import { canSSRAuth } from '../../utils/canSSRAuth'
import Head from 'next/head'
import { Box, } from "@chakra-ui/react";

import { NavBar } from '../../components/Header'
import CardPageVisits from '../../components/Card/CardPageVisits';
import CardSocialTraffic from '../../components/Card/CardSocialTraffic';
import CardStats from '../../components/Card/CardStats';
import Navbar from '../../components/Navbar';
import HeaderStats from '../../components/HeaderStart';
import Sidebar from '../../components/siderBar';

interface Props { }

export default function Home(props: Props) {

  return (
    <>
      <Head>
        <title>Painel - Dashboard</title>
      </Head>
      <Sidebar />
      <div className="relative md:ml-64 ">
        <Navbar />
        {/* Header */}
        <HeaderStats />
        <div className="flex flex-wrap">

        </div>
        <div className="px-4 md:px-10 mx-auto w-full -m-24">

            <div className="flex flex-wrap mt-4">

            <div className="w-full xl:w-8/12 mb-12 xl:mb-0 px-4">
              <CardPageVisits />
            </div>

            <div className="w-full xl:w-4/12 px-4">
              <CardSocialTraffic />
            </div>

          </div>
        </div>
      </div>
    </>
  )
}



export const getServerSideProps = canSSRAuth(async (ctx) => {

  return {
    props: {}
  }
})
