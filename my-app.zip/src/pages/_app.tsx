import '../styles/main.scss'
import "@fortawesome/fontawesome-free/css/all.min.css";
import type { AppProps } from 'next/app'
import { ChakraProvider } from '@chakra-ui/react'
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';
import { AuthProvider } from '../contexts/AuthContext'
import customTheme from '../styles/themes';

const colors = {
  text: {
    900: '#121212',
    400: '#1b1c29',
    100: '#c6c6c6'
  },
  primary: '#A94591',
  secondary: '#6C63FF',
  background: '#F0F0F5',
  textGray: '#6C6C80',
  white: '#fff',
}

function MyApp({ Component, pageProps }: AppProps) {

  return (

      <AuthProvider>
        <Component {...pageProps} />
        <ToastContainer autoClose={3000} position={'bottom-right'} />
      </AuthProvider>

  )
}

export default MyApp
