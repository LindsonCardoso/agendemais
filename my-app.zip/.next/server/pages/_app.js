/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/contexts/AuthContext.tsx":
/*!**************************************!*\
  !*** ./src/contexts/AuthContext.tsx ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"AuthContext\": () => (/* binding */ AuthContext),\n/* harmony export */   \"AuthProvider\": () => (/* binding */ AuthProvider),\n/* harmony export */   \"signOut\": () => (/* binding */ signOut)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! nookies */ \"nookies\");\n/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_4__]);\nreact_toastify__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\nconst AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});\nasync function signOut() {\n    // eslint-disable-next-line react-hooks/rules-of-hooks\n    try {\n        (0,nookies__WEBPACK_IMPORTED_MODULE_2__.destroyCookie)(undefined, \"@agendemais.token\");\n        next_router__WEBPACK_IMPORTED_MODULE_3___default().push(\"/\");\n    } catch  {\n        console.log(\"erro ao deslogar\");\n    }\n}\nfunction AuthProvider({ children  }) {\n    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();\n    //controlando se esta autenticado ou nao\n    const isAuthenticated = !!user;\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        //pegar o cookie\n        const { \"@agendemais.token\": token  } = (0,nookies__WEBPACK_IMPORTED_MODULE_2__.parseCookies)();\n        if (token) {\n            console.log(\"ok\");\n            let data = {\n                id: \"1\",\n                nome: \"lindson\",\n                login: \"lindson\",\n                email: \"l@i\"\n            };\n            const { id , login , email  } = data;\n            setUser({\n                id,\n                login,\n                email\n            });\n        }\n    }, []);\n    //funcao de login\n    async function signIn({ login , senha  }) {\n        try {\n            /*const response = await api.post('/login', {\n        name: login,\n        password\n      })*/ //const { id, name, token } = response.data;\n            let token = \"testeste@teste\";\n            //gerar cookies\n            (0,nookies__WEBPACK_IMPORTED_MODULE_2__.setCookie)(undefined, \"@agendemais.token\", token, {\n                maxAge: 60 * 60 * 24 * 30,\n                path: \"/\" //quais caminhos terao acesso ao cookie\n            });\n            setUser({\n                id: \"1\",\n                nome: \"lindson\",\n                login: \"lindson\",\n                email: \"l@i\"\n            });\n            //passar para proximas req o token\n            //api.defaults.headers['Authorization'] = `Bearer ${token}`\n            // home\n            // eslint-disable-next-line react-hooks/rules-of-hooks\n            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success(\"Bem vindo ao Agende+ \\uD83D\\uDC4B\");\n            next_router__WEBPACK_IMPORTED_MODULE_3___default().push(\"/home\");\n        } catch (err) {\n            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(\"Error ao acessar!\");\n            console.log(err);\n        }\n    }\n    async function signUp({ nome , celular , email , senha  }) {\n        //console.log(nome)\n        try {\n            /*\n     const response = await api.post('/cadastrar', {\n        nome,\n        celular,\n        email,\n        senha\n      })\n      */ //alert('ok')\n            console.log(nome, celular, email, senha);\n            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.success(\"Conta criada com sucesso!\");\n            next_router__WEBPACK_IMPORTED_MODULE_3___default().push(\"/\");\n        } catch (err) {\n            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(\"Error ao cadastrar!\");\n            console.log(err + \"Error ao cadastrar\");\n        }\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(AuthContext.Provider, {\n        value: {\n            user,\n            isAuthenticated,\n            signIn,\n            signOut,\n            signUp\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\l\\\\PDEV\\\\zltecnologia\\\\agende_mais\\\\my-app\\\\src\\\\contexts\\\\AuthContext.tsx\",\n        lineNumber: 158,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29udGV4dHMvQXV0aENvbnRleHQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQXNFO0FBQ0w7QUFFaEM7QUFHSTtBQWtDOUIsTUFBTVEsV0FBVyxpQkFBR1Asb0RBQWEsQ0FBQyxFQUFFLENBQW9CO0FBRXhELGVBQWVRLE9BQU8sR0FBRztJQUM5QixzREFBc0Q7SUFFdEQsSUFBSTtRQUNGTixzREFBYSxDQUFDTyxTQUFTLEVBQUUsbUJBQW1CLENBQUM7UUFDN0NKLHVEQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDbkIsRUFBRSxPQUFNO1FBQ05NLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLGtCQUFrQixDQUFDO0lBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRU0sU0FBU0MsWUFBWSxDQUFDLEVBQUVDLFFBQVEsR0FBcUIsRUFBRTtJQUU1RCxNQUFNLEtBQUNDLElBQUksTUFBRUMsT0FBTyxNQUFJakIsK0NBQVEsRUFBYTtJQUU3Qyx3Q0FBd0M7SUFDeEMsTUFBTWtCLGVBQWUsR0FBRyxDQUFDLENBQUNGLElBQUk7SUFHOUJkLGdEQUFTLENBQUMsSUFBTTtRQUVkLGdCQUFnQjtRQUNoQixNQUFNLEVBQUUsbUJBQW1CLEVBQUVpQixLQUFLLEdBQUUsR0FBR2YscURBQVksRUFBRTtRQUdyRCxJQUFJZSxLQUFLLEVBQUU7WUFDVFAsT0FBTyxDQUFDQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFbEIsSUFBSU8sSUFBSSxHQUFHO2dCQUNUQyxFQUFFLEVBQUUsR0FBRztnQkFDUEMsSUFBSSxFQUFFLFNBQVM7Z0JBQ2ZDLEtBQUssRUFBRSxTQUFTO2dCQUNoQkMsS0FBSyxFQUFFLEtBQUs7YUFDYjtZQUVELE1BQU0sRUFBRUgsRUFBRSxHQUFFRSxLQUFLLEdBQUVDLEtBQUssR0FBRSxHQUFHSixJQUFJO1lBRWpDSCxPQUFPLENBQUM7Z0JBQ05JLEVBQUU7Z0JBQ0ZFLEtBQUs7Z0JBQ0xDLEtBQUs7YUFDTixDQUFDO1FBR0osQ0FBQztJQUVILENBQUMsRUFBRSxFQUFFLENBQUM7SUFJTixpQkFBaUI7SUFDakIsZUFBZUMsTUFBTSxDQUFDLEVBQUNGLEtBQUssR0FBRUcsS0FBSyxHQUFjLEVBQUU7UUFDakQsSUFBSTtZQUNGOzs7UUFHRSxHQUVGLDRDQUE0QztZQUM1QyxJQUFJUCxLQUFLLEdBQUcsZ0JBQWdCO1lBQzVCLGVBQWU7WUFDZmQsa0RBQVMsQ0FBQ0ssU0FBUyxFQUFFLG1CQUFtQixFQUFFUyxLQUFLLEVBQUU7Z0JBQy9DUSxNQUFNLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRTtnQkFDekJDLElBQUksRUFBRSxHQUFHLENBQUMsdUNBQXVDO2FBQ2xELENBQUM7WUFFRlgsT0FBTyxDQUFDO2dCQUNOSSxFQUFFLEVBQUUsR0FBRztnQkFDUEMsSUFBSSxFQUFFLFNBQVM7Z0JBQ2ZDLEtBQUssRUFBRSxTQUFTO2dCQUNoQkMsS0FBSyxFQUFFLEtBQUs7YUFDYixDQUFDO1lBQ0Ysa0NBQWtDO1lBQ2xDLDJEQUEyRDtZQUUzRCxPQUFPO1lBQ1Asc0RBQXNEO1lBRXREakIseURBQWEsQ0FBQyxtQ0FBd0IsQ0FBQztZQUN2Q0QsdURBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUV2QixFQUFFLE9BQU93QixHQUFHLEVBQUU7WUFDWnZCLHVEQUFXLENBQUMsbUJBQW1CLENBQUM7WUFDaENLLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDaUIsR0FBRyxDQUFDO1FBQ2xCLENBQUM7SUFFSCxDQUFDO0lBRUQsZUFBZUUsTUFBTSxDQUFDLEVBQUNWLElBQUksR0FBRVcsT0FBTyxHQUFFVCxLQUFLLEdBQUVFLEtBQUssR0FBZ0IsRUFBQztRQUVqRSxtQkFBbUI7UUFDbkIsSUFBSTtZQUNIOzs7Ozs7O01BT0MsR0FDQSxhQUFhO1lBQ2JkLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDUyxJQUFJLEVBQUVXLE9BQU8sRUFBRVQsS0FBSyxFQUFFRSxLQUFLLENBQUM7WUFHeENuQix5REFBYSxDQUFDLDJCQUEyQixDQUFDO1lBQzFDRCx1REFBVyxDQUFDLEdBQUcsQ0FBQztRQUdsQixFQUFFLE9BQU93QixHQUFHLEVBQUU7WUFDWnZCLHVEQUFXLENBQUMscUJBQXFCLENBQUM7WUFDbENLLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDaUIsR0FBRyxHQUFHLG9CQUFvQixDQUFDO1FBQ3pDLENBQUM7SUFDSCxDQUFDO0lBRUQscUJBQ0UsOERBQUN0QixXQUFXLENBQUMwQixRQUFRO1FBQ25CQyxLQUFLLEVBQUU7WUFDTG5CLElBQUk7WUFDSkUsZUFBZTtZQUNmTyxNQUFNO1lBQ05oQixPQUFPO1lBQ1B1QixNQUFNO1NBQ1A7a0JBQ0FqQixRQUFROzs7OztZQUNZLENBQ3hCO0FBQ0gsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3NyYy9jb250ZXh0cy9BdXRoQ29udGV4dC50c3g/MWZhMiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgY3JlYXRlQ29udGV4dCwgUmVhY3ROb2RlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBkZXN0cm95Q29va2llLCBwYXJzZUNvb2tpZXMsIHNldENvb2tpZSB9IGZyb20gJ25vb2tpZXMnO1xuaW1wb3J0IHsgYXBpIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpQ2xpZW50JztcbmltcG9ydCBSb3V0ZXIgZnJvbSAnbmV4dC9yb3V0ZXInO1xuXG5cbmltcG9ydCB7dG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSdcblxudHlwZSBBdXRoQ29udGV4dERhdGEgPSB7XG4gIHVzZXI6IFVzZXJQcm9wcyB8IHVuZGVmaW5lZDtcbiAgaXNBdXRoZW50aWNhdGVkOiBib29sZWFuO1xuICBzaWduSW46IChjcmVkZW50aWFsczogU2luZ0luUHJvcHMpID0+IFByb21pc2U8dm9pZD47XG4gIHNpZ25PdXQ6ICgpID0+IHZvaWQ7XG4gIHNpZ25VcDogKGNyZWRlbnRpYWxzOiBTaWduVXBQcm9wcykgPT4gUHJvbWlzZTx2b2lkPjtcbn1cblxudHlwZSBVc2VyUHJvcHMgPSB7XG4gIGlkOiBzdHJpbmc7XG4gIG5vbWU/OiBzdHJpbmc7XG4gIGxvZ2luPzogc3RyaW5nO1xuICBlbWFpbD86IHN0cmluZztcbn1cblxudHlwZSBTaW5nSW5Qcm9wcyA9IHtcbiAgZW1haWw/OiBzdHJpbmc7XG4gIGxvZ2luPzogc3RyaW5nO1xuICBzZW5oYTogc3RyaW5nO1xufVxuXG50eXBlIEF1dGhQcm92aWRlclByb3BzID0ge1xuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xufVxuXG50eXBlIFNpZ25VcFByb3BzID0ge1xuICBub21lOiBzdHJpbmc7XG4gIGNlbHVsYXI6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbiAgc2VuaGE6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IEF1dGhDb250ZXh0ID0gY3JlYXRlQ29udGV4dCh7fSBhcyBBdXRoQ29udGV4dERhdGEpXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzaWduT3V0KCkge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3NcblxuICB0cnkge1xuICAgIGRlc3Ryb3lDb29raWUodW5kZWZpbmVkLCAnQGFnZW5kZW1haXMudG9rZW4nKVxuICAgIFJvdXRlci5wdXNoKFwiL1wiKTtcbiAgfSBjYXRjaCB7XG4gICAgY29uc29sZS5sb2coJ2Vycm8gYW8gZGVzbG9nYXInKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBBdXRoUHJvdmlkZXIoeyBjaGlsZHJlbiB9OiBBdXRoUHJvdmlkZXJQcm9wcykge1xuXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPFVzZXJQcm9wcz4oKTtcblxuICAvL2NvbnRyb2xhbmRvIHNlIGVzdGEgYXV0ZW50aWNhZG8gb3UgbmFvXG4gIGNvbnN0IGlzQXV0aGVudGljYXRlZCA9ICEhdXNlcjtcblxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG5cbiAgICAvL3BlZ2FyIG8gY29va2llXG4gICAgY29uc3QgeyAnQGFnZW5kZW1haXMudG9rZW4nOiB0b2tlbiB9ID0gcGFyc2VDb29raWVzKClcblxuXG4gICAgaWYgKHRva2VuKSB7XG4gICAgICBjb25zb2xlLmxvZygnb2snKTtcblxuICAgICAgbGV0IGRhdGEgPSB7XG4gICAgICAgIGlkOiAnMScsXG4gICAgICAgIG5vbWU6ICdsaW5kc29uJyxcbiAgICAgICAgbG9naW46ICdsaW5kc29uJyxcbiAgICAgICAgZW1haWw6ICdsQGknXG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHsgaWQsIGxvZ2luLCBlbWFpbCB9ID0gZGF0YTtcblxuICAgICAgc2V0VXNlcih7XG4gICAgICAgIGlkLFxuICAgICAgICBsb2dpbixcbiAgICAgICAgZW1haWxcbiAgICAgIH0pXG5cblxuICAgIH1cblxuICB9LCBbXSlcblxuXG5cbiAgLy9mdW5jYW8gZGUgbG9naW5cbiAgYXN5bmMgZnVuY3Rpb24gc2lnbkluKHtsb2dpbiwgc2VuaGF9OiBTaW5nSW5Qcm9wcykge1xuICAgIHRyeSB7XG4gICAgICAvKmNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoJy9sb2dpbicsIHtcbiAgICAgICAgbmFtZTogbG9naW4sXG4gICAgICAgIHBhc3N3b3JkXG4gICAgICB9KSovXG5cbiAgICAgIC8vY29uc3QgeyBpZCwgbmFtZSwgdG9rZW4gfSA9IHJlc3BvbnNlLmRhdGE7XG4gICAgICBsZXQgdG9rZW4gPSAndGVzdGVzdGVAdGVzdGUnXG4gICAgICAvL2dlcmFyIGNvb2tpZXNcbiAgICAgIHNldENvb2tpZSh1bmRlZmluZWQsICdAYWdlbmRlbWFpcy50b2tlbicsIHRva2VuLCB7XG4gICAgICAgIG1heEFnZTogNjAgKiA2MCAqIDI0ICogMzAsIC8vZXhwaXJhciBlbSB1bSBtZXNcbiAgICAgICAgcGF0aDogJy8nIC8vcXVhaXMgY2FtaW5ob3MgdGVyYW8gYWNlc3NvIGFvIGNvb2tpZVxuICAgICAgfSlcblxuICAgICAgc2V0VXNlcih7XG4gICAgICAgIGlkOiAnMScsXG4gICAgICAgIG5vbWU6ICdsaW5kc29uJyxcbiAgICAgICAgbG9naW46ICdsaW5kc29uJyxcbiAgICAgICAgZW1haWw6ICdsQGknXG4gICAgICB9KVxuICAgICAgLy9wYXNzYXIgcGFyYSBwcm94aW1hcyByZXEgbyB0b2tlblxuICAgICAgLy9hcGkuZGVmYXVsdHMuaGVhZGVyc1snQXV0aG9yaXphdGlvbiddID0gYEJlYXJlciAke3Rva2VufWBcblxuICAgICAgLy8gaG9tZVxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG5cbiAgICAgIHRvYXN0LnN1Y2Nlc3MoXCJCZW0gdmluZG8gYW8gQWdlbmRlKyDwn5GLXCIpXG4gICAgICBSb3V0ZXIucHVzaChcIi9ob21lXCIpO1xuXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIkVycm9yIGFvIGFjZXNzYXIhXCIpXG4gICAgICBjb25zb2xlLmxvZyhlcnIpXG4gICAgfVxuXG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBzaWduVXAoe25vbWUsIGNlbHVsYXIsIGVtYWlsLCBzZW5oYSB9OiAgU2lnblVwUHJvcHMpe1xuXG4gICAgLy9jb25zb2xlLmxvZyhub21lKVxuICAgIHRyeSB7XG4gICAgIC8qXG4gICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoJy9jYWRhc3RyYXInLCB7XG4gICAgICAgIG5vbWUsXG4gICAgICAgIGNlbHVsYXIsXG4gICAgICAgIGVtYWlsLFxuICAgICAgICBzZW5oYVxuICAgICAgfSlcbiAgICAgICovXG4gICAgICAvL2FsZXJ0KCdvaycpXG4gICAgICBjb25zb2xlLmxvZyhub21lLCBjZWx1bGFyLCBlbWFpbCwgc2VuaGEpXG5cblxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNvbnRhIGNyaWFkYSBjb20gc3VjZXNzbyFcIilcbiAgICAgIFJvdXRlci5wdXNoKCcvJylcblxuXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0b2FzdC5lcnJvcihcIkVycm9yIGFvIGNhZGFzdHJhciFcIilcbiAgICAgIGNvbnNvbGUubG9nKGVyciArIFwiRXJyb3IgYW8gY2FkYXN0cmFyXCIpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8QXV0aENvbnRleHQuUHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIHVzZXIsXG4gICAgICAgIGlzQXV0aGVudGljYXRlZCxcbiAgICAgICAgc2lnbkluLFxuICAgICAgICBzaWduT3V0LFxuICAgICAgICBzaWduVXBcbiAgICAgIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XG4gIClcbn1cbiJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImNyZWF0ZUNvbnRleHQiLCJ1c2VFZmZlY3QiLCJkZXN0cm95Q29va2llIiwicGFyc2VDb29raWVzIiwic2V0Q29va2llIiwiUm91dGVyIiwidG9hc3QiLCJBdXRoQ29udGV4dCIsInNpZ25PdXQiLCJ1bmRlZmluZWQiLCJwdXNoIiwiY29uc29sZSIsImxvZyIsIkF1dGhQcm92aWRlciIsImNoaWxkcmVuIiwidXNlciIsInNldFVzZXIiLCJpc0F1dGhlbnRpY2F0ZWQiLCJ0b2tlbiIsImRhdGEiLCJpZCIsIm5vbWUiLCJsb2dpbiIsImVtYWlsIiwic2lnbkluIiwic2VuaGEiLCJtYXhBZ2UiLCJwYXRoIiwic3VjY2VzcyIsImVyciIsImVycm9yIiwic2lnblVwIiwiY2VsdWxhciIsIlByb3ZpZGVyIiwidmFsdWUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/contexts/AuthContext.tsx\n");

/***/ }),

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_main_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/main.scss */ \"./src/styles/main.scss\");\n/* harmony import */ var _styles_main_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_main_scss__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fortawesome/fontawesome-free/css/all.min.css */ \"./node_modules/@fortawesome/fontawesome-free/css/all.min.css\");\n/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ \"./node_modules/react-toastify/dist/ReactToastify.css\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\n/* harmony import */ var _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../contexts/AuthContext */ \"./src/contexts/AuthContext.tsx\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_4__, _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__]);\n([react_toastify__WEBPACK_IMPORTED_MODULE_4__, _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\nconst colors = {\n    text: {\n        900: \"#121212\",\n        400: \"#1b1c29\",\n        100: \"#c6c6c6\"\n    },\n    primary: \"#A94591\",\n    secondary: \"#6C63FF\",\n    background: \"#F0F0F5\",\n    textGray: \"#6C6C80\",\n    white: \"#fff\"\n};\nfunction MyApp({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_5__.AuthProvider, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\l\\\\PDEV\\\\zltecnologia\\\\agende_mais\\\\my-app\\\\src\\\\pages\\\\_app.tsx\",\n                lineNumber: 28,\n                columnNumber: 9\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {\n                autoClose: 3000,\n                position: \"bottom-right\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\l\\\\PDEV\\\\zltecnologia\\\\agende_mais\\\\my-app\\\\src\\\\pages\\\\_app.tsx\",\n                lineNumber: 29,\n                columnNumber: 9\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\l\\\\PDEV\\\\zltecnologia\\\\agende_mais\\\\my-app\\\\src\\\\pages\\\\_app.tsx\",\n        lineNumber: 27,\n        columnNumber: 7\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUE0QjtBQUMyQjtBQUdSO0FBQ0M7QUFDTTtBQUd0RCxNQUFNRSxNQUFNLEdBQUc7SUFDYkMsSUFBSSxFQUFFO0FBQ0osV0FBRyxFQUFFLFNBQVM7QUFDZCxXQUFHLEVBQUUsU0FBUztBQUNkLFdBQUcsRUFBRSxTQUFTO0tBQ2Y7SUFDREMsT0FBTyxFQUFFLFNBQVM7SUFDbEJDLFNBQVMsRUFBRSxTQUFTO0lBQ3BCQyxVQUFVLEVBQUUsU0FBUztJQUNyQkMsUUFBUSxFQUFFLFNBQVM7SUFDbkJDLEtBQUssRUFBRSxNQUFNO0NBQ2Q7QUFFRCxTQUFTQyxLQUFLLENBQUMsRUFBRUMsU0FBUyxHQUFFQyxTQUFTLEdBQVksRUFBRTtJQUVqRCxxQkFFSSw4REFBQ1YsK0RBQVk7OzBCQUNYLDhEQUFDUyxTQUFTO2dCQUFFLEdBQUdDLFNBQVM7Ozs7O29CQUFJOzBCQUM1Qiw4REFBQ1gsMERBQWM7Z0JBQUNZLFNBQVMsRUFBRSxJQUFJO2dCQUFFQyxRQUFRLEVBQUUsY0FBYzs7Ozs7b0JBQUk7Ozs7OztZQUNoRCxDQUVsQjtBQUNILENBQUM7QUFFRCxpRUFBZUosS0FBSyIsInNvdXJjZXMiOlsid2VicGFjazovL215LWFwcC8uL3NyYy9wYWdlcy9fYXBwLnRzeD9mOWQ2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL21haW4uc2NzcydcbmltcG9ydCBcIkBmb3J0YXdlc29tZS9mb250YXdlc29tZS1mcmVlL2Nzcy9hbGwubWluLmNzc1wiO1xuaW1wb3J0IHR5cGUgeyBBcHBQcm9wcyB9IGZyb20gJ25leHQvYXBwJ1xuaW1wb3J0IHsgQ2hha3JhUHJvdmlkZXIgfSBmcm9tICdAY2hha3JhLXVpL3JlYWN0J1xuaW1wb3J0ICdyZWFjdC10b2FzdGlmeS9kaXN0L1JlYWN0VG9hc3RpZnkuY3NzJztcbmltcG9ydCB7IFRvYXN0Q29udGFpbmVyIH0gZnJvbSAncmVhY3QtdG9hc3RpZnknO1xuaW1wb3J0IHsgQXV0aFByb3ZpZGVyIH0gZnJvbSAnLi4vY29udGV4dHMvQXV0aENvbnRleHQnXG5pbXBvcnQgY3VzdG9tVGhlbWUgZnJvbSAnLi4vc3R5bGVzL3RoZW1lcyc7XG5cbmNvbnN0IGNvbG9ycyA9IHtcbiAgdGV4dDoge1xuICAgIDkwMDogJyMxMjEyMTInLFxuICAgIDQwMDogJyMxYjFjMjknLFxuICAgIDEwMDogJyNjNmM2YzYnXG4gIH0sXG4gIHByaW1hcnk6ICcjQTk0NTkxJyxcbiAgc2Vjb25kYXJ5OiAnIzZDNjNGRicsXG4gIGJhY2tncm91bmQ6ICcjRjBGMEY1JyxcbiAgdGV4dEdyYXk6ICcjNkM2QzgwJyxcbiAgd2hpdGU6ICcjZmZmJyxcbn1cblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuXG4gIHJldHVybiAoXG5cbiAgICAgIDxBdXRoUHJvdmlkZXI+XG4gICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgPFRvYXN0Q29udGFpbmVyIGF1dG9DbG9zZT17MzAwMH0gcG9zaXRpb249eydib3R0b20tcmlnaHQnfSAvPlxuICAgICAgPC9BdXRoUHJvdmlkZXI+XG5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBNeUFwcFxuIl0sIm5hbWVzIjpbIlRvYXN0Q29udGFpbmVyIiwiQXV0aFByb3ZpZGVyIiwiY29sb3JzIiwidGV4dCIsInByaW1hcnkiLCJzZWNvbmRhcnkiLCJiYWNrZ3JvdW5kIiwidGV4dEdyYXkiLCJ3aGl0ZSIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiYXV0b0Nsb3NlIiwicG9zaXRpb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./node_modules/@fortawesome/fontawesome-free/css/all.min.css":
/*!********************************************************************!*\
  !*** ./node_modules/@fortawesome/fontawesome-free/css/all.min.css ***!
  \********************************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/react-toastify/dist/ReactToastify.css":
/*!************************************************************!*\
  !*** ./node_modules/react-toastify/dist/ReactToastify.css ***!
  \************************************************************/
/***/ (() => {



/***/ }),

/***/ "./src/styles/main.scss":
/*!******************************!*\
  !*** ./src/styles/main.scss ***!
  \******************************/
/***/ (() => {



/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "nookies":
/*!**************************!*\
  !*** external "nookies" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react-toastify":
/*!*********************************!*\
  !*** external "react-toastify" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();